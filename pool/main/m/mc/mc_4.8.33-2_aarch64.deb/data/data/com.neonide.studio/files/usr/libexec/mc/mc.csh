alias mc 'source /data/data/com.neonide.studio/files/usr/libexec/mc/mc-wrapper.csh'
