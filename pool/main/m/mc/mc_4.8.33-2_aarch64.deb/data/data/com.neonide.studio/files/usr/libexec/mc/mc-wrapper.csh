if ($?MC_TMPDIR) then
	setenv MC_PWD_FILE "`mktemp '$MC_TMPDIR/mc.pwd.XXXXXX'`"
else if ($?TMPDIR) then
	setenv MC_PWD_FILE "`mktemp '$TMPDIR/mc.pwd.XXXXXX'`"
else
	setenv MC_PWD_FILE "`mktemp '/tmp/mc.pwd.XXXXXX'`"
endif

/data/data/com.neonide.studio/files/usr/bin/mc -P "$MC_PWD_FILE" $*

if (-r "$MC_PWD_FILE") then
	setenv MC_PWD "`cat '$MC_PWD_FILE'`"
	if ("$MC_PWD" != "$cwd" && -d "$MC_PWD") then
		cd "$MC_PWD" || true
	endif
	unsetenv MC_PWD
endif

rm -f "$MC_PWD_FILE"
unsetenv MC_PWD_FILE
