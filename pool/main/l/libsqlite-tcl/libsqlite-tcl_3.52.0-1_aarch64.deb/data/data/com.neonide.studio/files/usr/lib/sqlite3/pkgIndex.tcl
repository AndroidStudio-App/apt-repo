# -*- tcl -*-
# Tcl package index file, version ???
#
package ifneeded sqlite3 3.52.0 \
    [list load [file join $dir libsqlite3.52.0.so] Sqlite3]

