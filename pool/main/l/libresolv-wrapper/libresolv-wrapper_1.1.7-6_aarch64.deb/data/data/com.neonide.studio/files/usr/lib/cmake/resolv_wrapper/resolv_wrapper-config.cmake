set(RESOLV_WRAPPER_LIBRARY /data/data/com.neonide.studio/files/usr/lib/libresolv_wrapper.so)
